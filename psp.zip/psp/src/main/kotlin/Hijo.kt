fun main() {
    println("Hijo: Preparado para adivinar el número.")
    val reader = System.`in`.bufferedReader()
    val writer = System.out.bufferedWriter()

    var respuesta: String
    var intento = 50 // Comienza en el medio del rango (1 a 100)
    var min = 1
    var max = 100

    do {
        println("Hijo: Intento -> $intento")
        writer.write("$intento\n")
        writer.flush()

        respuesta = reader.readLine() ?: "correcto"

        when (respuesta) {
            "mayor" -> min = intento + 1
            "menor" -> max = intento - 1
            "correcto" -> println("Hijo: ¡Adiviné el número!")
        }

        intento = (min + max) / 2
    } while (respuesta != "correcto")
}
