import java.io.*
import kotlin.random.Random

fun main() {
    val numeroSecreto = Random.nextInt(1, 101) // Genera un número entre 1 y 100
    println("Padre: Número secreto generado. El hijo debe adivinar $numeroSecreto.")

    try {
        val processBuilder = ProcessBuilder( "java", "-cp", "C:\\Users\\ADMIN\\Documents\\GitHub\\HANAN_RAFIK_DAM1\\psp\\out\\production\\psp", "Hijokt")
        val process = processBuilder.start()

        val inputFromChild = BufferedReader(InputStreamReader(process.inputStream))
        val outputToChild = BufferedWriter(OutputStreamWriter(process.outputStream))

        var adivinado = false

        while (!adivinado) {
            val intento = inputFromChild.readLine()?.toIntOrNull() ?: break
            println("Padre: El hijo intenta con -> $intento")

            when {
                intento < numeroSecreto -> {
                    println("Padre: Respuesta -> mayor")
                    outputToChild.write("mayor\n")
                }
                intento > numeroSecreto -> {
                    println("Padre: Respuesta -> menor")
                    outputToChild.write("menor\n")
                }
                else -> {
                    println("Padre: Respuesta -> correcto")
                    outputToChild.write("correcto\n")
                    adivinado = true
                }
            }

            outputToChild.flush()
        }

        val exitCode = process.waitFor()
        println("Padre: El proceso hijo terminó con código de salida: $exitCode")
    } catch (e: Exception) {
        e.printStackTrace()
    }}
